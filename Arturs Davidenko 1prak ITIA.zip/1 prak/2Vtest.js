'use strict';

var net = require('net');
var sockets = [];
var names = [];
var registeredUsers = {}; // A map to track registered users
var register = new RegExp("@NAME:.*");
var listUser = new RegExp("@USERS");
var privateMessage = new RegExp("@PM:(\\w+):(.*)");
var svr = net.createServer(function (socket) {
    socket.write('Chat serveris v0.0.0.1\n');
    socket.write('Comands:\n');
    socket.write('@NAME:\n');
    socket.write('@USERS\n');
    socket.write('@PM:\n');
    var isRegistered = false; 
    var username;

    socket.on('data', function (data) {
        var message = data.toString('utf8').trim();
        if (!isRegistered && register.test(message)) {
            username = message.substring(6);
            if (!registeredUsers[username]) {
                isRegistered = true;
                registeredUsers[username] = socket;
                sockets.push(socket);
                names.push(username);
                socket.write('You are now registered as ' + username + '\n');
            } else {
                socket.write('Username ' + username + ' is already taken. Choose a different name.\n');
            }
        } else if (isRegistered) {
            if (listUser.test(message)) {
                socket.write('Users online:\n');
                for (var j = 0; j < names.length; j++) {
                    socket.write(names[j] + '\n');
                }
            } else if (privateMessage.test(message)) {
                var match = privateMessage.exec(message);
                var recipient = match[1];
                var pmContent = match[2];
                sendPrivateMessage(username, recipient, pmContent);
            } else {
                var index = sockets.indexOf(socket);
                for (var i = 0; i < sockets.length; i++) {
                    if (sockets[i] !== socket) {
                        sockets[i].write(' username: */[' + username + '] message is: ' + message + '\n');
                    }
                }
            }
        } else {
            socket.write('You must register with @NAME:yourname before chatting.\n');
        }
    });

    socket.on('end', function () {
        var i = sockets.indexOf(socket);
        if (i !== -1) {
            sockets.splice(i, 1);
            names.splice(i, 1);
        }
        if (username) {
            delete registeredUsers[username];
        }
    });

    function sendPrivateMessage(sender, recipient, message) {
        if (recipient in registeredUsers) {
            var recipientSocket = registeredUsers[recipient];
            recipientSocket.write('Sender:' + sender + ' message is: ' + message + '\n');
        } else {
            socket.write('User ' + recipient + ' is not online or does not exist.\n');
        }
    }
});

svr.listen(8000, '127.0.0.1'); 
