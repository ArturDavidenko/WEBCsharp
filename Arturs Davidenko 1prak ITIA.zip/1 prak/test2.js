'use strict'
//var net = require('net');
//var svr = net.createServer(function(socket) {
//        socket.on('data',function(data){
//            var buf = new Buffer(data);
//            console.log(buf.toString())
//       });    
//    });
//svr.listen(8000, 'localhost');

'use strict';
var net = require('net');

var svr = net.createServer(function(socket) {
    socket.on('data', function(data) {
        var buf = new Buffer(data);
        console.log(data);
        console.log(buf.toString());
    });


    var s = 'HTTP/1.1 302 Found\r\n';
    s += 'Server: VIETEJAIS\r\n';
    s += 'Location: http://www.llu.lv/lv/r/n'; // Specify the redirection URL
    s += 'Connection: close\r\n\r\n';

    var buffer = new Buffer(s);
    console.log(buffer);
    socket.end(buffer);
});

svr.listen(8000, 'localhost');

