﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_Core__4_uzd_
{
    internal class BookCategory
    {
        public int BookCategoryId { get; set; }

        public Book Book { get; set; }

        public int CategoryId { get; set; }

        public Categories Categories { get; set; }
    }
}
