﻿using System;

namespace EF_Core__4_uzd_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (var context = new SimpleContext())
            {
                for (int i = 0; i < 10; i++)
                {
                    var author = new Authors
                    {
                        FirstName = $"FirstName{i}",
                        LastName = $"LastName{i}"
                    };

                    var category = new Categories
                    {
                        categoryName = $"Category{i}",
                        categoryDescription = $"Category Description {i}"
                    };

                    var book = new Book
                    {
                        Title = $"BookTitle{i}",
                        DateOfPublishes = "12.02.2002",
                        CountOFPages = 300,
                        Authors = author
                    };

                    book.BookCategory = new List<BookCategory>
                    {
                        new BookCategory { Categories = category, Book = book }
                    };

                    context.Authors.Add(author);
                    context.Categories.Add(category);
                    context.Book.Add(book);
                }

                context.SaveChanges();
            }

            using (var context = new SimpleContext())
            {

                var selectedBook = context.Book.FirstOrDefault(b => b.Title == "BookTitle0");
                if (selectedBook != null)
                {
                    selectedBook.Authors.FirstName = "NewAuthorFirstName";
                    selectedBook.Authors.LastName = "NewAuthorLastName";
                    context.SaveChanges();
                }


                var bookToUpdate = context.Book.FirstOrDefault(b => b.Title == "BookTitle1");
                if (bookToUpdate != null)
                {
                    bookToUpdate.Title = "NewBookTitle";
                    bookToUpdate.Authors.FirstName = "UpdatedAuthorFirstName";
                    bookToUpdate.Authors.LastName = "UpdatedAuthorLastName";
                    context.SaveChanges();
                }


                var categoryToDelete = context.Categories.FirstOrDefault(c => c.categoryName == "Category1");
                if (categoryToDelete != null)
                {
                    context.Categories.Remove(categoryToDelete);
                    context.SaveChanges();
                }
            }

        }
    }
}