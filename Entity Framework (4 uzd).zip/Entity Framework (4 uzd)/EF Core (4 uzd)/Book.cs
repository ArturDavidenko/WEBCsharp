﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_Core__4_uzd_
{
    internal class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public string DateOfPublishes { get; set; }
        public int CountOFPages { get; set; }

        public int AuthorId { get; set; }
        public Authors Authors { get; set; }

        public ICollection<BookCategory> BookCategory { get; set; }

    }
}
