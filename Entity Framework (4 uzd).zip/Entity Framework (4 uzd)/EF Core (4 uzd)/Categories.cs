﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_Core__4_uzd_
{
    internal class Categories
    {
        public int CategoriesId { get; set; }

        public string categoryName { get; set; }

        public string categoryDescription { get; set; }

        public ICollection<BookCategory> BookCategories { get; set; }
    }
}
