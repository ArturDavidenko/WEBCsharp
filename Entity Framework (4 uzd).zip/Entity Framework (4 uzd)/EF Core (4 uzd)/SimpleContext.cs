﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_Core__4_uzd_
{
    internal class SimpleContext : DbContext
    {
        public SimpleContext()
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("Host=localhost;Database=Libary2;Username=postgres;Password=1234");
        }


        public DbSet<Book> Book { get; set; }
        public DbSet<Authors> Authors { get; set; }
        public DbSet<Categories> Categories { get; set; }

        public DbSet<BookCategory> BookCategory { get; set; }
    }
}
