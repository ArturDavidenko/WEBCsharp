﻿using System.Security.Cryptography.X509Certificates;

namespace RazorTraining__3_uzd_.Model
{
    public class QuestionRepository
    {
        public List<QuationsModel> Questions { get; }

        public QuestionRepository()
        {
            Questions = new List<QuationsModel>
            {
                new QuationsModel
                {
                    Text = "How is my name ?(Who created this app)",
                    Answers = new string[] {"Arturs", "Maks", "Lev"},
                    CorrectAnswerIndex = 0
                },

                new QuationsModel
                {
                    Text = "How old are I am?",
                    Answers = new string[] {"21", "22", "23"},
                    CorrectAnswerIndex = 0

                },

                new QuationsModel
                {
                    Text = "My favorite game is?",
                    Answers = new string[] {"Valorant", "Elden Ring", "Dark Souls II"},
                    CorrectAnswerIndex = 1

                },


                new QuationsModel
                {
                    Text = "My favorite drink is?",
                    Answers = new string[] {"Cola", "Fanta", "Sprite"},
                    CorrectAnswerIndex = 1

                },

                new QuationsModel
                {
                    Text = "Which one lenguage writen this app?",
                    Answers = new string[] {"C#", "Java", "Python"},
                    CorrectAnswerIndex = 0

                },

                new QuationsModel
                {
                    Text = "What learning in this app?",
                    Answers = new string[] {"XAML", "MVC Arhitecrture", "Razor"},
                    CorrectAnswerIndex = 2

                },

                new QuationsModel
                {
                    Text = "How much money i spend on the way to LBTU",
                    Answers = new string[] {"2 euro", "1 euro", "3 euro"},
                    CorrectAnswerIndex = 0

                },

                new QuationsModel
                {
                    Text = "My favorite brand of devices?",
                    Answers = new string[] {"HyperX", "Logitec", "Razer"},
                    CorrectAnswerIndex = 1

                },

                new QuationsModel
                {
                    Text = "For what i learing in LBTU",
                    Answers = new string[] {"To make great carier of Programmer", "For fun", "Parents tell me get education"},
                    CorrectAnswerIndex = 0

                },

                new QuationsModel
                {
                    Text = "Which answer was on first questions?",
                    Answers = new string[] {"1", "2", "3"},
                    CorrectAnswerIndex = 0

                },

                new QuationsModel
                {
                    Text = "Now is course is? ",
                    Answers = new string[] {"1", "2", "3"},
                    CorrectAnswerIndex = 2

                },

                new QuationsModel
                {
                    Text = "How much time i spent to travet to LBTU",
                    Answers = new string[] {"2 hours", "1 hour", "30 min"},
                    CorrectAnswerIndex = 0

                }
            };

        }

        public QuationsModel GetQuestion(int number)
        {
            if (number >= 1 && number <= Questions.Count)
            {
                return Questions[number - 1];
            }
            return null;
        }

        public void SetUserAnswer(int questionNumber, int answerIndex)
        {
            if (questionNumber >= 1 && questionNumber <= Questions.Count && answerIndex >= 0 && answerIndex < Questions[questionNumber - 1].Answers.Length)
            {
                Questions[questionNumber - 1].UserAnsweredIndex = answerIndex;
            }
        }
    }
}
