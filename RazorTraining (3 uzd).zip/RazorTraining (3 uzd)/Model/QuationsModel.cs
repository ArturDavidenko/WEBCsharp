﻿namespace RazorTraining__3_uzd_.Model
{
    public class QuationsModel
    {
        public string Text { get; set; }
        public string[] Answers { get; set; }
        public int CorrectAnswerIndex { get; set; }
        public int UserAnsweredIndex { get; set; }  

        public bool IsAnswerCorrect => UserAnsweredIndex == CorrectAnswerIndex;
    }
}
