﻿namespace RazorTraining__3_uzd_.Model
{
    public class SummaryViewModel
    {
            public string QuestionText { get; set; }
            public string UserAnswer { get; set; }
            public string CorrectAnswer { get; set; }
            public bool IsCorrect { get; set; }
    }
}
