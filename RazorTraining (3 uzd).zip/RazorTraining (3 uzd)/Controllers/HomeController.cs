﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RazorTraining__3_uzd_.Model;

namespace RazorTraining__3_uzd_.Controllers
{
    public class HomeController : Controller
    {
        // GET: HomeController
        private readonly QuestionRepository _questionRepository;
        public HomeController()
        {
            _questionRepository = new QuestionRepository(); 
        }
        public ActionResult Index()
        {
            return View();
        }

      // public IActionResult SummaryPage()
      // {
      //     return View("SummaryPage");
      // }

        public IActionResult Question(int number)
        {
            ViewBag.QuestionIndex = number;
            var question = _questionRepository.GetQuestion(number);
            if (question == null)
            {
                return NotFound();
            }

            return View("Question", question);
        }

        [HttpPost]
        public IActionResult SubmitAnswer(int questionNumber, int answerIndex)
        {
            _questionRepository.SetUserAnswer(questionNumber, answerIndex);

            // Check if this is the last question
            if (questionNumber >= _questionRepository.Questions.Count - 1)
            {
                // Redirect to the summary page
                return RedirectToAction("SummaryPage");
            }
            else
            {
                // Redirect to the next question
                return RedirectToAction("Question", new { number = questionNumber + 1 });
            }
        }


        public IActionResult SummaryPage()
        {
           var answeredQuestions = _questionRepository.Questions
                .Where(q => q.UserAnsweredIndex != -1)
                .ToList();
       
            return View(answeredQuestions);
        }



    }
}
