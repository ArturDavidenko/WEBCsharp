﻿using Microsoft.AspNetCore.Mvc;
using Quiz2Web.Data;
using Quiz2Web.Models;

public class HomeController : Controller
{
    private readonly QuestionRepository _questionRepository;

    public HomeController(QuestionRepository questionRepository)
    {
        _questionRepository = questionRepository;
    }

    public IActionResult Index()
    {
        ViewData["QuestionRepository"] = _questionRepository;
        return View();
    }

    public IActionResult Question(int number)
    {
        Question question = _questionRepository.GetQuestion(number);

        if (question == null)
        {
            return NotFound();
        }
        bool isAnswered = _questionRepository.IsQuestionAnswered(number);

        ViewData["IsAnswered"] = isAnswered;
        ViewData["QuestionRepository"] = _questionRepository;
        return View(question);
    }

    [HttpPost]
    public IActionResult SubmitAnswer(int number, int answer)
    {
        Question question = _questionRepository.GetQuestion(number);
        int questionIndex = _questionRepository.GetQuestionIndex(question);

        question.UserAnswered = answer;
        _questionRepository.SaveChanges();

        if (number != 15)
        {
            return RedirectToAction("Question", new { number = questionIndex + 1 });
        }
        else
        {
            return RedirectToAction("Summary");
        }
        
    }

    public IActionResult Summary()
    {
        ViewData["QuestionRepository"] = _questionRepository;
        if (_questionRepository.GetAnsweredQuestionsCount() == 15)
        {
            SummaryViewModel summaryViewModel = new SummaryViewModel
            {
                Questions = _questionRepository.GetAllQuestionsWithAnswers()
            };

            return View(summaryViewModel);
        }
        else
        {
            return View("Complete");
        }
    }
    [HttpGet]
    public IActionResult AddQuestion()
    {
        ViewData["QuestionRepository"] = _questionRepository;
        return View();
    }

    [HttpPost]
    public IActionResult AddQuestion(Question question)
    {
        ViewData["QuestionRepository"] = _questionRepository;
        // Validate that there are no more than 5 answers
        if (question.Answers.Count > 5)
        {
            ModelState.AddModelError("Answers", "A question cannot have more than 5 answers.");
            return View(question);
        }

        // Save the question and answers to the database
        _questionRepository.AddQuestion(question);
        return RedirectToAction("Index"); // Redirect to the homepage or another suitable page
    }




}

