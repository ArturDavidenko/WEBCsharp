using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System.Configuration;
using System.Data;
using System.Data.Common;
using Quiz2Web.Data;
using static System.Net.Mime.MediaTypeNames;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddScoped<QuestionRepository>();
builder.Services.AddDbContext<Context>(options =>
{
	options.UseNpgsql(builder.Configuration.GetConnectionString("QuizDatabase"));
});
var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.UseEndpoints(endpoints =>
{
	endpoints.MapControllerRoute(
		name: "default",
		pattern: "{controller=Home}/{action=Index}/{id?}");
});
app.UseEndpoints(endpoints =>
{
	endpoints.MapControllerRoute(
		name: "question",
		pattern: "{controller=Home}/{action=Question}/{number}");
});
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var context = services.GetRequiredService<Context>();
    var questionRepository = services.GetRequiredService<QuestionRepository>();

    // Reset user answers
    questionRepository.ResetUserAnswers();

}

//using (var scope = app.Services.CreateScope())
//{
//	var services = scope.ServiceProvider;
//	var context = services.GetRequiredService<Context>();
//	var dataSeeder = new FillingDb(context);
//	dataSeeder.SeedDatabase();
//}

app.Run();

