﻿using Microsoft.EntityFrameworkCore;
using Quiz2Web.Models;

namespace Quiz2Web.Data
{
	public class FillingDb
	{
		private readonly Context _context;

		public FillingDb(Context context)
		{
			_context = context;
		}
		public void SeedDatabase()
		{

			List<Question> questionEntities = new List<Question>
			{
				new Question
				{
					Text = "How is my name ?(Who created this app)",
					Answers = new List<Answer>
					{
						new Answer {Text = "Arturs", IsCorrect = true},
						new Answer {Text = "Maks", IsCorrect = false },
						new Answer {Text = "Lev", IsCorrect = false }
					},
				},
				new Question
				{
					Text = "How old are I am?",
					Answers = new List<Answer>
					{
						new Answer {Text = "21", IsCorrect = true},
						new Answer {Text = "22", IsCorrect = false},
						new Answer {Text = "23", IsCorrect = false}
					}
				},
				new Question
				{
					Text = "My favorite game is?",
					Answers = new List<Answer>
					{
						new Answer {Text =  "Elden Ring", IsCorrect = true },
						new Answer {Text = "Valorant", IsCorrect = false },
						new Answer {Text = "Dark Souls II", IsCorrect = false }
					}
				},
				new Question
				{
				   Text = "My favorite drink is?",
					Answers = new List<Answer>
					{
						new Answer {Text = "Cola", IsCorrect = true},
						new Answer {Text = "Fanta", IsCorrect = false },
						new Answer {Text = "Sprite", IsCorrect = false }
					}
				},
				new Question
				{
					Text = "Which one lenguage writen this app?",
					Answers = new List<Answer>
					{
						new Answer {Text = "C#", IsCorrect = true },
						new Answer { Text = "Java", IsCorrect = false },
						new Answer { Text = "Python", IsCorrect = false }
					}
				},
				new Question
				{
					Text = "What learning in this app?",
					Answers = new List<Answer>
					{
						new Answer {Text = "MVC", IsCorrect = true },
						new Answer {Text = "XAML", IsCorrect = false },
						new Answer { Text = "Razor", IsCorrect = false }
					}
				},
				new Question
				{
					Text = "How much money i spend on the way to LBTU?",
					Answers = new List<Answer>
					{
						new Answer { Text = "1 euro", IsCorrect = false },
						new Answer { Text = "2 euro", IsCorrect = true },
						new Answer { Text = "3 euro", IsCorrect = false }
					}
				},
				new Question
				{
					Text = "My favorite brand of devices?",
					Answers = new List<Answer>
					{
						new Answer { Text = "HyperX", IsCorrect = false },
						new Answer { Text = "Razor", IsCorrect = false },
						new Answer { Text = "Logitec", IsCorrect = true }
					}
				},
				new Question
				{
					Text = "Which answer was on first questions?",
					Answers = new List<Answer>
					{
						new Answer { Text = "1", IsCorrect = true },
						new Answer { Text = "2", IsCorrect = false },
						new Answer { Text = "3", IsCorrect = false }
					}
				},
				new Question
				{
					Text = "For what i learing in LBTU?",
					Answers = new List<Answer>
					{
						new Answer { Text = "To make great carier of Programmer", IsCorrect = true },
						new Answer { Text = "For fun", IsCorrect = false },
						new Answer { Text = "Parents tell me get education", IsCorrect = false }
					}
				},
				new Question
				{
					Text = "Now is course is?",
					Answers = new List<Answer>
					{
						new Answer { Text = "1", IsCorrect = true },
						new Answer { Text = "2", IsCorrect =false  },
						new Answer { Text = "3", IsCorrect = false }
					}
				},
				new Question
				{
					Text = "How much time i spent to travet to LBTU?",
					Answers = new List<Answer>
					{
						new Answer { Text = "2 hour", IsCorrect = false },
						new Answer { Text = "30 min", IsCorrect = false },
						new Answer { Text = "1 hour", IsCorrect = true }
					}
				}
			};
			foreach (var question in questionEntities)
			{
				_context.Questions.Add(question);
			}
			_context.SaveChanges();
		}
	}
}
