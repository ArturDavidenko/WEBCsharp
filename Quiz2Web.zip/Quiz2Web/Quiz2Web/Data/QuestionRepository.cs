﻿using Microsoft.EntityFrameworkCore;
using Quiz2Web.Models;


namespace Quiz2Web.Data
{
    public class QuestionRepository
    {
        private readonly Context _context;
        public QuestionRepository(Context context)
        {
            _context = context;
        }
        public void ResetUserAnswers()
        {
            var questions = _context.Questions.ToList();
            foreach (var question in questions)
            {
                question.UserAnswered = -1;
            }
            _context.SaveChanges();
        }

        public Question GetQuestion(int number)
        {
            return _context.Questions.Include(q => q.Answers).FirstOrDefault(q => q.QuestionId == number);
        }

        public List<Question> GetAllQuestionsWithAnswers()
        {
            return _context.Questions.Include(q => q.Answers).ToList();
        }

        public bool IsQuestionAnswered(int questionNumber)
        {
            Question question = GetQuestion(questionNumber);
            if (question.UserAnswered == -1)
            {
                return false;
            }
            return true;
        }

        public int GetAnsweredQuestionsCount()
        {
            return _context.Questions.Count(q => q.UserAnswered != -1);
        }

        public int GetQuestionIndex(Question question)
        {
            return question.QuestionId;
        }
        public void AddQuestion(Question question)
        {
            _context.Questions.Add(question);
            _context.SaveChanges();
        }

        public void AddAnswer(Answer answer)
        {
            _context.Answers.Add(answer);
            _context.SaveChanges();
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}



