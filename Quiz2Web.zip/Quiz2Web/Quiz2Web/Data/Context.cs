﻿using Microsoft.EntityFrameworkCore;
using Quiz2Web.Models;
using System;

namespace Quiz2Web.Data
{
	public class Context : DbContext
	{
		public DbSet<Question> Questions { get; set; }
		public DbSet<Answer> Answers { get; set; }

		public Context(DbContextOptions<Context> options) : base(options) { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Answer>()
                .HasOne(a => a.Question)
                .WithMany(q => q.Answers)
                .HasForeignKey(a => a.QuestionId);

            modelBuilder.Entity<Question>()
                .Property(q => q.UserAnswered).HasDefaultValue(-1);
        }


    }
}
