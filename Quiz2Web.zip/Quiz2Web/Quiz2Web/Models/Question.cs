﻿	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.ComponentModel.DataAnnotations;
	using System.ComponentModel.DataAnnotations.Schema;
	using Quiz2Web.Models;

	namespace Quiz2Web.Models
	{
		public class Question
		{
			[Key]
			[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			public int QuestionId { get; set; }
			public string Text { get; set; }
			public ICollection<Answer> Answers { get; set; }
			public int UserAnswered { get; set; }
		}
	}

