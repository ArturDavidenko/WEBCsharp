﻿using System.ComponentModel.DataAnnotations;

namespace Quiz2Web.Models
{
    public class QuestionFormModel
    {
        public string QuestionText { get; set; }

        public ICollection<Answer> Answers { get; set; }
    }
    public class AnswerFormModel
    {
        public string AnswerText { get; set; }

        public bool IsCorrect { get; set; }
    }
}
