﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Quiz2Web.Models;

namespace Quiz2Web.Models
{
	public class Answer
	{
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
		public int AnswerId { get; set; }
		public string Text { get; set; }
		public bool IsCorrect { get; set; }
        public int QuestionId { get; set; }
        public Question Question { get; set; }
	}
}
