﻿namespace Quiz2Web.Models
{
    public class SummaryViewModel
    {
        public List<Question> Questions { get; set; }
    }   
}


