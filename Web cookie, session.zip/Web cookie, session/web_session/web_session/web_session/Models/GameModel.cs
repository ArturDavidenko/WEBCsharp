﻿namespace web_session.Models
{
    public class GameModel
    {
        public int Guess { get; set; }
        public int Score { get; set; }
        public int RandomNumber { get; set; }
        public DateTime StartTime { get; set; }
        public int MinRange { get; set; }
        public int MaxRange { get; set; }

        public GameModel()
        {
            MinRange = 1;
            MaxRange = 100;
        }
    }
}





