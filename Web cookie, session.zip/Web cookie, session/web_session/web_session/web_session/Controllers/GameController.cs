﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using web_session.Models;
namespace web_session.Controllers
{
    public class GameController : Controller
    {
        private const string GuessKey = "Guess";
        private const string ScoreKey = "Score";
        private const string RandomNumberKey = "RandomNumber";
        private const string StartTimeKey = "StartTime";

        [HttpGet]
        public IActionResult Index()
        {
            var gameModel = GetGameModelFromSession();

            if (gameModel.Score < 10)
            {
                if (gameModel.Guess == gameModel.RandomNumber)
                {
                    ViewBag.Result = "Correct!";
                }
                else if (gameModel.Guess < gameModel.RandomNumber)
                {
                    ViewBag.Result = "Too Low";
                }
                else
                {
                    ViewBag.Result = "Too High";
                }

                return View("Index", gameModel);
            }
            else
            {
                HttpContext.Session.Clear();
                return RedirectToAction("GameOver");
            }
        }

        [HttpPost]
        public IActionResult SubmitGuess(int guess)
        {
            var gameModel = GetGameModelFromSession();
            if (gameModel.Score < 10)
            {
                gameModel.Score++;  
                if (guess == gameModel.RandomNumber)
                {
                    ViewBag.Result = "Correct!";
                }
                else if (guess < gameModel.RandomNumber)
                {
                    ViewBag.Result = "Too Low";
                }
                else
                {
                    ViewBag.Result = "Too High";
                }

                int difference = Math.Abs(guess - gameModel.RandomNumber);

                if (difference < Math.Abs(gameModel.Guess - gameModel.RandomNumber))
                {
                    gameModel.Guess = guess;
                }
                UpdateGameModelInSession(gameModel);

                return View("Index", gameModel);
            }
            else
            {
                HttpContext.Session.Clear();
                return View("Index", gameModel);
            }
        }

        [HttpPost]
        public IActionResult SetRange(int minRange, int maxRange)
        {
            var gameModel = new GameModel
            {
                MinRange = minRange,
                MaxRange = maxRange,
                RandomNumber = new Random().Next(minRange, maxRange + 1),
                StartTime = DateTime.Now
            };

            UpdateGameModelInSession(gameModel);

            ViewBag.ShowRangeForm = false;

            return View("Index", gameModel);
        }

        private GameModel GetGameModelFromSession()
        {
            if (HttpContext.Session.TryGetValue(GuessKey, out byte[] guessBytes) &&
                HttpContext.Session.TryGetValue(ScoreKey, out byte[] scoreBytes) &&
                HttpContext.Session.TryGetValue(RandomNumberKey, out byte[] randomNumberBytes) &&
                HttpContext.Session.TryGetValue(StartTimeKey, out byte[] startTimeBytes))
            {
                var gameModel = new GameModel
                {
                    Guess = BitConverter.ToInt32(guessBytes, 0), 
                    Score = BitConverter.ToInt32(scoreBytes, 0), 
                    RandomNumber = BitConverter.ToInt32(randomNumberBytes),
                    StartTime = DateTime.FromBinary(BitConverter.ToInt64(startTimeBytes))
                };

                return gameModel;
            }
            else
            {
                ViewBag.ShowRangeForm = true;

                var newGame = new GameModel
                {
                    Score = 0,
                    Guess = 0
                };

                UpdateGameModelInSession(newGame);

                return newGame;
            }
        }


        private void UpdateGameModelInSession(GameModel gameModel)
        {
            HttpContext.Session.Set(GuessKey, BitConverter.GetBytes(gameModel.Guess));
            HttpContext.Session.Set(ScoreKey, BitConverter.GetBytes(gameModel.Score)); 
            HttpContext.Session.SetInt32(RandomNumberKey, gameModel.RandomNumber);
            HttpContext.Session.Set(StartTimeKey, BitConverter.GetBytes(gameModel.StartTime.ToBinary()));
        }
    }
}











