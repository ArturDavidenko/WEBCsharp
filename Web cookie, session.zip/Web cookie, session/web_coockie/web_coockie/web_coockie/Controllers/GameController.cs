﻿using Microsoft.AspNetCore.Mvc;
using web_coockie.Models;

namespace web_coockie.Controllers
{
    public class GameController : Controller
    {
        private const string GuessKey = "Guess";
        private const string ScoreKey = "Score";
        private const string RandomNumberKey = "RandomNumber";

		[HttpGet]
		public IActionResult Index()
		{
			if (HttpContext.Request.Cookies.TryGetValue(GuessKey, out string guessValue) &&
				HttpContext.Request.Cookies.TryGetValue(ScoreKey, out string scoreValue) &&
				HttpContext.Request.Cookies.TryGetValue(RandomNumberKey, out string randomNumberValue))
			{
				var gameModel = new GameModel
				{
					Guess = int.Parse(guessValue),
					Score = int.Parse(scoreValue),
					RandomNumber = int.Parse(randomNumberValue)
				};

				if (gameModel.Score < 10)
				{
					if (gameModel.Guess == gameModel.RandomNumber)
					{
						ViewBag.Result = "Correct!";
					}
					else if (gameModel.Guess < gameModel.RandomNumber)
					{
						ViewBag.Result = "Too Low";
					}
					else
					{
						ViewBag.Result = "Too High";
					}

					return View(gameModel);
				}
				else
				{
					HttpContext.Response.Cookies.Delete(GuessKey);
					HttpContext.Response.Cookies.Delete(ScoreKey);
					HttpContext.Response.Cookies.Delete(RandomNumberKey);

					return RedirectToAction("GameOver");
				}
			}
			else
			{
				var newGame = new GameModel
				{
					RandomNumber = new Random().Next(1, 101),
					Score = 0,
					Guess = 0
				};
				HttpContext.Response.Cookies.Append(GuessKey, newGame.Guess.ToString());
				HttpContext.Response.Cookies.Append(ScoreKey, newGame.Score.ToString());
				HttpContext.Response.Cookies.Append(RandomNumberKey, newGame.RandomNumber.ToString());

				return View(newGame);
			}
		}



		[HttpPost]
        public IActionResult SubmitGuess(int guess)
        {
            var guessValue = HttpContext.Request.Cookies[GuessKey];
            var scoreValue = HttpContext.Request.Cookies[ScoreKey];
            var randomNumberValue = HttpContext.Request.Cookies[RandomNumberKey];

            var gameModel = new GameModel
            {
                Guess = guess,
                Score = int.Parse(scoreValue),
                RandomNumber = int.Parse(randomNumberValue)
            };
            if (guess == gameModel.RandomNumber)
            {
                ViewBag.Result = "Correct!";
            }
            else if (guess < gameModel.RandomNumber)
            {
                ViewBag.Result = "Too Low";
            }
            else
            {
                ViewBag.Result = "Too High";
            }
            if (gameModel.Score < 9)
            {
                HttpContext.Response.Cookies.Append(GuessKey, gameModel.Guess.ToString());
                HttpContext.Response.Cookies.Append(ScoreKey, (gameModel.Score + 1).ToString());
            }
            else
            {
                HttpContext.Response.Cookies.Delete(GuessKey);
                HttpContext.Response.Cookies.Delete(ScoreKey);
                HttpContext.Response.Cookies.Delete(RandomNumberKey);
            }

            return View("Index", gameModel);
        }
    }
}
