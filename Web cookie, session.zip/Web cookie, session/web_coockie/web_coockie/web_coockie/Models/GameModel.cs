﻿namespace web_coockie.Models
{
    public class GameModel
    {
        public int Guess { get; set; }
        public int Score { get; set; }
        public int RandomNumber { get; set; }
    }
}
